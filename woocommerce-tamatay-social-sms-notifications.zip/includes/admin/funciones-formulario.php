<?php
// Make sure this file is not accessed directly
defined( 'ABSPATH' ) || exit;

global $tamatay_social_sms_settings, $wpml_activo, $mensajes;

// Set tabulation
$tab = 1;

// WPML
if ( $tamatay_social_sms_settings ) {
    foreach ( $mensajes as $mensaje_key => $mensaje ) {
        if ( function_exists( 'icl_register_string' ) || ! $wpml_activo ) { // Version prior to 3.2
            $mensajes[ $mensaje_key ] = ( $wpml_activo ) ? icl_translate( 'tamatay_social_sms', $mensaje, esc_textarea( $tamatay_social_sms_settings[ $mensaje_key ] ) ) : esc_textarea( $tamatay_social_sms_settings[ $mensaje_key ] );
        } else if ( $wpml_activo ) { // Version 3.2 or higher
            $mensajes[ $mensaje_key ] = apply_filters( 'wpml_translate_single_string', esc_textarea( $tamatay_social_sms_settings[ $mensaje_key ] ), 'tamatay_social_sms', $mensaje );
        }
    }
} else { // Initialize variables
    foreach ( $mensajes as $mensaje_key => $mensaje ) {
        $mensajes[ $mensaje_key ] = '';
    }
}

// List of SMS providers
$listado_de_proveedores = [
    'waapi' => 'WhatsApp Notifications - Tamatay.com',
    'msg91' => '91SMS.in',
];
asort( $listado_de_proveedores, SORT_NATURAL | SORT_FLAG_CASE ); // Sort providers alphabetically

// Fields required for each provider
$campos_de_proveedores = [
    'msg91' => [
        'clave_msg91' => __( 'authentication key', 'woocommerce-tamatay-social-sms-notifications' ),
        'identificador_msg91' => __( 'sender ID', 'woocommerce-tamatay-social-sms-notifications' ),
        'ruta_msg91' => __( 'route', 'woocommerce-tamatay-social-sms-notifications' ),
        'dlt_msg91' => __( 'template ID', 'woocommerce-tamatay-social-sms-notifications' ),
    ],
    'waapi' => [
        'usuario_waapi' => __( 'Client ID', 'woocommerce-tamatay-social-sms-notifications' ),
        'contrasena_waapi' => __( 'Instance ID', 'woocommerce-tamatay-social-sms-notifications' ),
    ],
];

// Options for provider selection fields
$opciones_de_proveedores = [
    'ruta_msg91' => [
        'default' => __( 'Default', 'woocommerce-tamatay-social-sms-notifications' ),
        1 => 1,
        4 => 4,
    ],
];

// Verification fields
$verificacion_de_proveedores = [
    'short_sendsms',
    'gdpr_sendsms',
    'dlt_moplet',
    'dlt_msg91',
];

// List of order statuses
$listado_de_estados = wc_get_order_statuses();
$listado_de_estados_temporal = [];
$estados_originales = [
'pending',
'failed',
'on-hold',
'processing',
'completed',
'refunded',
'cancelled',
];
foreach ($listado_de_estados as $clave => $estado) {
$nombre_de_estado = str_replace("wc-", "", $clave);
if (!in_array($nombre_de_estado, $estados_originales)) {
$listado_de_estados_temporal[$estado] = $nombre_de_estado;
}
}
$listado_de_estados = $listado_de_estados_temporal;

// List of custom messages
$listado_de_mensajes = [
'todos' => __('All messages', 'woocommerce-tamatay-social-sms-notifications'),
'mensaje_pedido' => __('Owner custom message', 'woocommerce-tamatay-social-sms-notifications'),
'mensaje_pendiente' => __('Order pending custom message', 'woocommerce-tamatay-social-sms-notifications'),
'mensaje_fallido' => __('Order failed custom message', 'woocommerce-tamatay-social-sms-notifications'),
'mensaje_recibido' => __('Order on-hold custom message', 'woocommerce-tamatay-social-sms-notifications'),
'mensaje_procesando' => __('Order processing custom message', 'woocommerce-tamatay-social-sms-notifications'),
'mensaje_completado' => __('Order completed custom message', 'woocommerce-tamatay-social-sms-notifications'),
'mensaje_devuelto' => __('Order refunded custom message', 'woocommerce-tamatay-social-sms-notifications'),
'mensaje_cancelado' => __('Order cancelled custom message', 'woocommerce-tamatay-social-sms-notifications'),
'mensaje_nota' => __('Notes custom message', 'woocommerce-tamatay-social-sms-notifications'),
];

/*
Pinta el campo select con el listado de proveedores
*/
function tamatay_social_sms_listado_de_proveedores( $listado_de_proveedores ) {
    global $tamatay_social_sms_settings;
    
    foreach ( $listado_de_proveedores as $valor => $proveedor ) {
        $chequea = ( isset( $tamatay_social_sms_settings['servicio'] ) && $tamatay_social_sms_settings['servicio'] == $valor ) ? ' selected="selected"' : '';
        echo '<option value="' . esc_attr( $valor ) . '"' . $chequea . '>' . esc_html( $proveedor ) . '</option>' . PHP_EOL;
    }
}


/*
Pinta los campos de los proveedores
*/
function tamatay_social_sms_campos_de_proveedores( $listado_de_proveedores, $campos_de_proveedores, $opciones_de_proveedores, $verificacion_de_proveedores ) {
    global $tamatay_social_sms_settings, $tab;
    
    foreach ( $listado_de_proveedores as $valor => $proveedor ) {
        foreach ( $campos_de_proveedores[$valor] as $valor_campo => $campo ) {
            if ( array_key_exists( $valor_campo, $opciones_de_proveedores ) ) { //Campo select
                echo '
                <tr valign="top" class="' . $valor . '"><!-- ' . $proveedor . ' -->
                    <th scope="row" class="titledesc">
                        <label for="tamatay_social_sms_settings[' . $valor_campo . ']">' . ucfirst( $campo ) . ': <span class="woocommerce-help-tip" data-tip="' . sprintf( __( 'The %s for your account in %s', 'woocommerce-tamatay-social-sms-notifications' ), $campo, $proveedor ) . '"></span></label>
                    </th>
                    <td class="forminp forminp-number">
                        <select class="wc-enhanced-select" id="tamatay_social_sms_settings[' . $valor_campo . ']" name="tamatay_social_sms_settings[' . $valor_campo . ']" tabindex="' . $tab++ . '">';
                
                foreach ( $opciones_de_proveedores[$valor_campo] as $valor_opcion => $opcion ) {
                    $chequea = ( isset( $tamatay_social_sms_settings[$valor_campo] ) && $tamatay_social_sms_settings[$valor_campo] == $valor_opcion ) ? ' selected="selected"' : '';
                    echo '<option value="' . esc_attr( $valor_opcion ) . '"' . $chequea . '>' . $opcion . '</option>' . PHP_EOL;
                }
                
                echo '          </select>
                    </td>
                </tr>
                ';
           } elseif ( in_array( $valor_campo, $verificacion_de_proveedores ) ) { //Campo checkbox
                $dlt        = ( strpos( $valor_campo, "dlt_" ) !== false ) ? ' class="dlt"' : '';
                $chequea    = ( isset( $tamatay_social_sms_settings[$valor_campo] ) && $tamatay_social_sms_settings[$valor_campo] == 1 ) ? ' checked="checked"' : '';
                echo '
  <tr valign="top" class="' . $valor . '"><!-- ' . $proveedor . ' -->
    <th scope="row" class="titledesc"> <label for="tamatay_social_sms_settings[' . $valor_campo . ']">' . ucfirst( $campo ) . ':' . '
      <span class="woocommerce-help-tip" data-tip="' . sprintf( __( 'The %s for your account in %s', 'woocommerce-tamatay-social-sms-notifications' ), $campo, $proveedor ) . '"></span></label></th>
    <td class="forminp forminp-number"><input type="checkbox"' . $dlt . ' id="tamatay_social_sms_settings[' . $valor_campo . ']" name="tamatay_social_sms_settings[' . $valor_campo . ']" value="1"' . $chequea . ' tabindex="' . $tab++ . '" ></td>
  </tr>
                ';
            } else { //Campo input
                echo '
  <tr valign="top" class="' . $valor . '"><!-- ' . $proveedor . ' -->
    <th scope="row" class="titledesc"> <label for="tamatay_social_sms_settings[' . $valor_campo . ']">' . ucfirst( $campo ) . ':' . '
      <span class="woocommerce-help-tip" data-tip="' . sprintf( __( 'The %s for your account in %s', 'woocommerce-tamatay-social-sms-notifications' ), $campo, $proveedor ) . '"></span></label></th>
    <td class="forminp forminp-number"><input type="text" id="tamatay_social_sms_settings[' . $valor_campo . ']" name="tamatay_social_sms_settings[' . $valor_campo . ']" size="50" value="' . ( isset( $tamatay_social_sms_settings[$valor_campo] ) ? esc_attr( $tamatay_social_sms_settings[$valor_campo] ) : '' ) . '" tabindex="' . $tab++ . '" /></td>
  </tr>
                ';
            }
        }
    }
}


/**
 * Prints the fields of the shipping form in the checkout page.
 */
function tamatay_social_sms_campos_de_envio() {
    global $tamatay_social_sms_settings;

    $country = new WC_Countries();
    $fields = $country->get_address_fields($country->get_base_country(), 'shipping_'); // Get default fields
    $custom_fields = apply_filters('woocommerce_checkout_fields', []); // Get custom fields
    if (isset($custom_fields['shipping'])) {
        $fields += $custom_fields['shipping']; // Merge custom fields with default fields
    }

    foreach ($fields as $key => $field) {
        $selected = (isset($tamatay_social_sms_settings['campo_envio']) && $tamatay_social_sms_settings['campo_envio'] == $key) ? 'selected="selected"' : '';
        if (isset($field['label'])) {
            printf('<option value="%s" %s>%s</option>%s', esc_attr($key), $selected, esc_html($field['label']), PHP_EOL);
        }
    }
}


/*
Pinta el campo select con el listado de estados de pedido
*/
function tamatay_social_sms_listado_de_estados( $listado_de_estados ) {
    global $tamatay_social_sms_settings;

    // Check if the custom states are set
    $estados_personalizados = isset( $tamatay_social_sms_settings['estados_personalizados'] ) ? $tamatay_social_sms_settings['estados_personalizados'] : array();

    foreach( $listado_de_estados as $nombre_de_estado => $estado ) {
        $chequea = '';
        if ( in_array( $estado, $estados_personalizados ) ) {
            $chequea = ' selected="selected"';
        }
        echo '<option value="' . esc_attr( $estado ) . '"' . $chequea . '>' . $nombre_de_estado . '</option>' . PHP_EOL;
    }
}


/*
Pinta el campo select con el listado de mensajes personalizados
*/
function tamatay_social_sms_listado_de_mensajes( $listado_de_mensajes ) {
    global $tamatay_social_sms_settings;
    
    $selected_values = isset( $tamatay_social_sms_settings['mensajes'] ) ? (array) $tamatay_social_sms_settings['mensajes'] : array();
    $all_option_selected = empty( $selected_values ) ? ' selected="selected"' : '';
    
    foreach ( $listado_de_mensajes as $valor => $mensaje ) {
        $selected = in_array( $valor, $selected_values ) ? ' selected="selected"' : '';
        echo '<option value="' . esc_attr( $valor ) . '"' . $selected . '>' . $mensaje . '</option>' . PHP_EOL;
    }
    echo '<option value="todos"' . $all_option_selected . '>' . __( 'Todos', 'tamatay-social-sms' ) . '</option>' . PHP_EOL;
}




/*
Pinta los campos de mensajes
*/
function tamatay_social_sms_campo_de_mensaje_personalizado( $campo, $campo_cliente, $listado_de_mensajes ) {
    global $tab, $tamatay_social_sms_settings;
    
    //Listado de mensajes personalizados
    $listado_de_mensajes_personalizados = [
        'mensaje_pedido'       => __( 'Order No. %s received on ', 'woocommerce-tamatay-social-sms-notifications' ),
        'mensaje_pendiente'    => __( 'Thank you for shopping with us! Your order No. %s is now: %s', 'woocommerce-tamatay-social-sms-notifications' ),
        'mensaje_fallido'      => __( 'Thank you for shopping with us! Your order No. %s has failed to complete. %s', 'woocommerce-tamatay-social-sms-notifications' ),
        'mensaje_recibido'     => __( 'Your order No. %s is received on %s. Thank you for shopping with us!', 'woocommerce-tamatay-social-sms-notifications' ),
        'mensaje_procesando'   => __( 'Thank you for shopping with us! Your order No. %s is now: %s', 'woocommerce-tamatay-social-sms-notifications' ),
        'mensaje_completado'   => __( 'Thank you for shopping with us! Your order No. %s has been completed. %s', 'woocommerce-tamatay-social-sms-notifications' ),
        'mensaje_devuelto'     => __( 'Thank you for shopping with us! Your order No. %s has been refunded. %s', 'woocommerce-tamatay-social-sms-notifications' ),
        'mensaje_cancelado'    => __( 'Thank you for shopping with us! Your order No. %s has been cancelled. %s', 'woocommerce-tamatay-social-sms-notifications' ),
        'mensaje_nota'         => __( 'A note has just been added to your order No. %s: %s', 'woocommerce-tamatay-social-sms-notifications' ),
    ];

    //Listado de textos personalizados
    $listado_de_textos_personalizados = [
        'mensaje_pendiente'    => __( 'Pending', 'woocommerce-tamatay-social-sms-notifications' ),
        'mensaje_fallido'      => __( 'Failed', 'woocommerce-tamatay-social-sms-notifications' ),
        'mensaje_procesando'   => __( 'Processing', 'woocommerce-tamatay-social-sms-notifications' ),
        'mensaje_completado'   => __( 'Completed', 'woocommerce-tamatay-social-sms-notifications' ),
        'mensaje_devuelto'     => __( 'Refunded', 'woocommerce-tamatay-social-sms-notifications' ),
        'mensaje_cancelado'    => __( 'Cancelled', 'woocommerce-tamatay-social-sms-notifications' ),
    ];

    if ( $campo == 'mensaje_pedido'  ) {
    $texto  = stripcslashes( ! empty( $campo_cliente ) ? $campo_cliente : sprintf( __( $listado_de_mensajes_personalizados[ $campo ], 'woocommerce-tamatay-social-sms-notifications' ), "%id%" ) . $tamatay_social_sms_settings['shop_name'] . "." );
} elseif ( $campo == 'mensaje_recibido'  ) {
    $texto  = stripcslashes( ! empty( $campo_cliente ) ? $campo_cliente : sprintf( __( $listado_de_mensajes_personalizados[ $campo ], 'woocommerce-tamatay-social-sms-notifications' ), "%id%", $tamatay_social_sms_settings['shop_name'] ) );
} elseif ( $campo == 'mensaje_nota'  ) {
    $texto  = stripcslashes( ! empty( $campo_cliente ) ? $campo_cliente : sprintf( __( $listado_de_mensajes_personalizados[ $campo ], 'woocommerce-tamatay-social-sms-notifications' ), "%id%" ) . "%note%" );
} else {
    $texto  = stripcslashes( ! empty( $campo_cliente ) ? $campo_cliente : sprintf( __( $listado_de_mensajes_personalizados[ $campo ], 'woocommerce-tamatay-social-sms-notifications' ), "%id%" ) . __( $listado_de_textos_personalizados[ $campo ], 'woocommerce-tamatay-social-sms-notifications' ) . "." );
}
// Updated listado de mensajes personalizados - DLT
$listado_de_mensajes_dlt = [
    'mensaje_pedido'           => __( 'Owner custom message template ID', 'woocommerce-tamatay-social-sms-notifications' ),
    'mensaje_pendiente'        => __( 'Order pending custom message template ID', 'woocommerce-tamatay-social-sms-notifications' ),
    'mensaje_fallido'          => __( 'Order failed custom message template ID', 'woocommerce-tamatay-social-sms-notifications' ),
    'mensaje_recibido'         => __( 'Order on-hold custom message template ID', 'woocommerce-tamatay-social-sms-notifications' ),
    'mensaje_procesando'       => __( 'Order processing custom message template ID', 'woocommerce-tamatay-social-sms-notifications' ),
    'mensaje_completado'       => __( 'Order completed custom message template ID', 'woocommerce-tamatay-social-sms-notifications' ),
    'mensaje_devuelto'         => __( 'Order refunded custom message template ID', 'woocommerce-tamatay-social-sms-notifications' ),
    'mensaje_cancelado'        => __( 'Order cancelled custom message template ID', 'woocommerce-tamatay-social-sms-notifications' ),
    'mensaje_nota'             => __( 'Notes custom message template ID', 'woocommerce-tamatay-social-sms-notifications' ),
    'mensaje_nuevo'            => __( 'New order custom message template ID', 'woocommerce-tamatay-social-sms-notifications' ), // added new message
    'mensaje_enviado'          => __( 'Order shipped custom message template ID', 'woocommerce-tamatay-social-sms-notifications' ), // added new message
    'mensaje_rechazado'        => __( 'Order rejected custom message template ID', 'woocommerce-tamatay-social-sms-notifications' ), // added new message
    'mensaje_espera_pago'      => __( 'Order waiting payment custom message template ID', 'woocommerce-tamatay-social-sms-notifications' ), // added new message
    'mensaje_nota_envio'       => __( 'Shipping notes custom message template ID', 'woocommerce-tamatay-social-sms-notifications' ), // modified message
];

$texto_dlt = isset( $tamatay_social_sms_settings[ 'dlt_' . $campo ] ) ? $tamatay_social_sms_settings[ 'dlt_' . $campo ] : '';
    
echo '<tr valign="top" class="' . esc_attr( $campo ) . '">
    <th scope="row" class="titledesc">
        <label for="tamatay_social_sms_settings[' . esc_attr( $campo ) . ']">
            ' . esc_html__( $listado_de_mensajes[ $campo ], 'woocommerce-tamatay-social-sms-notifications' ) .':
            <span class="woocommerce-help-tip" data-tip="'. esc_attr__( 'You can customize your message. Remember that you can use this variables: %id%, %order_key%, %billing_first_name%, %billing_last_name%, %billing_company%, %billing_address_1%, %billing_address_2%, %billing_city%, %billing_postcode%, %billing_country%, %billing_state%, %billing_email%, %billing_phone%, %shipping_first_name%, %shipping_last_name%, %shipping_company%, %shipping_address_1%, %shipping_address_2%, %shipping_city%, %shipping_postcode%, %shipping_country%, %shipping_state%, %shipping_method%, %shipping_method_title%, %payment_method%, %payment_method_title%, %order_discount%, %cart_discount%, %order_tax%, %order_shipping%, %order_shipping_tax%, %order_total%, %status%, %prices_include_tax%, %tax_display_cart%, %display_totals_ex_tax%, %display_cart_ex_tax%, %order_date%, %modified_date%, %customer_message%, %customer_note%, %post_status%, %shop_name%, %order_product% and %note%.', 'woocommerce-tamatay-social-sms-notifications' ) . '"></span>
        </label>
    </th>
    <td class="forminp forminp-number">
        <textarea id="tamatay_social_sms_settings[' . esc_attr( $campo ) . ']" name="tamatay_social_sms_settings[' . esc_attr( $campo ) . ']" cols="50" rows="5" tabindex="' . esc_attr( $tab++ ) . '">' . esc_textarea( $texto ) . '</textarea>
    </td>
</tr>
<tr valign="top" class="mensaje_dlt dlt_' . esc_attr( $campo ) . '">
    <th scope="row" class="titledesc">
        <label for="tamatay_social_sms_settings[dlt_' . esc_attr( $campo ) . ']">
            ' . esc_html__( $listado_de_mensajes_dlt[ $campo ], 'woocommerce-tamatay-social-sms-notifications' ) .':
            <span class="woocommerce-help-tip" data-tip="'. esc_attr__( 'Template ID for ' . $listado_de_mensajes[ $campo ], 'woocommerce-tamatay-social-sms-notifications' ) . '"></span>
        </label>
    </th>
    <td class="forminp forminp-number">
        <input type="text" id="tamatay_social_sms_settings[dlt_' . esc_attr( $campo ) . ']" name="tamatay_social_sms_settings[dlt_' . esc_attr( $campo ) . ']" size="50" value="' . esc_attr( $texto_dlt ) . '" tabindex="' . esc_attr( $tab++ ) . '"/>
    </td>
</tr>';
 }
